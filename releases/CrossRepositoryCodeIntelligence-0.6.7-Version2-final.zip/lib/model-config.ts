export const DEFAULT_OPENAI_MODEL = "gpt-5.6-sol";

